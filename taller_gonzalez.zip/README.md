# taller_gonzalez
Pa trabajar los subnormales de la clase
Queda hacer el footer de la plantilla y que fenoy se meta y ponga el puñetero codigo en el github
